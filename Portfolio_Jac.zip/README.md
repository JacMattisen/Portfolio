Portfolio under construction according to my progress in studies

